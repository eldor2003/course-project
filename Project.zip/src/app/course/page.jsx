import CoursePage from "@/pages/CoursePage";
import React from "react";

const Course = () => {
	return (
		<>
			<CoursePage />
		</>
	);
};

export default Course;
